<?php

require_once 'Connection.class.php';

class UserConfiguration {
    public function convertFromIdToName($id) {
        try{
            $conn = new Connection();
            $connectionEstablished = $conn->_establishConnection();
            $sql = "SELECT UsernameUsuario FROM usuarios_chory WHERE Id_usuarios=:id";
            $stmt = $connectionEstablished->prepare($sql);
            $stmt->bindParam(":id", $id, PDO::PARAM_INT);
            $stmt->execute();
            while($gettingData = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $username[] = $gettingData;
            }
            $conn->_killConnection($conn);
            return $username;
        }catch(PDOException $e) {
            echo "{Error: " . $e->getMessage() . "};";
            return false;
        }
    }
}
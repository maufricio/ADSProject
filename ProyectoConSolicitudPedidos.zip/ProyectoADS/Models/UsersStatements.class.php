<?php

require_once 'Connection.class.php';

class UserStatements {

    public function registerUser($name, $lastname, $email, $username, $password) {
        try{
            $conn = new Connection();
            $db = $conn->_establishConnection();
            $valorId = 1;
            $sql = "INSERT INTO usuarios_chory (
            NombreUsuario, 
            ApellidoUsuario,
            CorreoUsuario, 
            UsernameUsuario, 
            PasswordUsuario,
            RolUsuario) 
            VALUES(:nombre_usuario, :apellido_usuario, :correo_usuario, :username_usuario, :password_usuario, :rol_usuario)";
            $stmt = $db->prepare($sql);
            $passwordHashed = hash('sha256', $password);
            $name = trim($name);
            $lastname = trim($lastname);
            $email = trim($email);
            $username = trim($username);
            $stmt->bindParam(":nombre_usuario", $name, PDO::PARAM_STR);
            $stmt->bindParam(":apellido_usuario", $lastname, PDO::PARAM_STR);
            $stmt->bindParam(":correo_usuario", $email, PDO::PARAM_STR);
            $stmt->bindParam(":username_usuario", $username, PDO::PARAM_STR);
            $stmt->bindParam(":password_usuario", $passwordHashed, PDO::PARAM_STR);
            $stmt->bindParam(":rol_usuario", $valorId, PDO::PARAM_INT);
            if($stmt) {
                $stmt->execute();
            }else{
                echo "<div class='alert alert-danger' role='alert'>Acción realizada sin éxito.</div>";
                echo $countUsername;
            }
            $conn->_killConnection($conn);
        } catch (PDOException $e) {
            echo "{Error: " . $e->getMessage() . "};";
            return false;
        }
    }

    public function userLogin($username, $password){
        try{
            //$path = "";
            $modelo = new Connection();
            $db = $modelo->_establishConnection();
            $hashingPassword = hash('sha256', $password);
            $stmt = $db->prepare("SELECT Id_usuarios, RolUsuario FROM usuarios_chory WHERE (UsernameUsuario=:username OR CorreoUsuario=:username) AND PasswordUsuario=:contrasenia");
            $stmt->bindParam(":username",$username,PDO::PARAM_STR);//variable que se reemplaza como parametro de funcion
            $stmt->bindParam(":contrasenia", $hashingPassword, PDO::PARAM_STR);
            $stmt->execute();
            $count = $stmt->rowCount();//Usuario encontrado, contado como encontrado una unica vez
            $data = $stmt->fetch();//Informacion del usuario encontrado
            $db = null; //Se rompe la conexion con base de datos
            if($count){
                session_start();
                $_SESSION['Id_usuarios'] = $data['Id_usuarios']; //almacenando la sesion del usuario, como tipo SESSION
                $_SESSION['RolUsuario'] = $data['RolUsuario'];
                return true;
            }else{
                return false; 
            }
        }catch(PDOException $e){
            echo '{"error":{"text":'.$e->getMessage().'}}';
        }
    }

    public function insertOrderRequest($id, $products) {
        try{
            $conn = new Connection();
            $db = $conn->_establishConnection();
            $orderStatus = 1;
            $sql = "INSERT INTO solicitud_pedidos (Id_usuarioSolicitante, ProductosPedidos, TipoEstado) VALUES(:id, :productos, :estadoPedido)";
            $stmt = $db->prepare($sql);
            $stmt->bindParam(":id", $id, PDO::PARAM_INT);
            $stmt->bindParam(":productos", $products, PDO::PARAM_STR);
            $stmt->bindParam(":estadoPedido", $orderStatus, PDO::PARAM_INT);
            if($stmt) {
                $stmt->execute();
            }else{
                echo "<div class='alert alert-danger' role='alert'>Acción realizada sin éxito.</div>";
                echo $countUsername;
            }
            $conn->_killConnection($conn);
        } catch (PDOException $e) {
            echo "{Error: " . $e->getMessage() . "};";
            return false;
        }
    }

    public function selectOrderRequestsByUser($id) {
        try{
            $ordersRequested = [];
            $conn = new Connection();
            $methodToConnect = $conn->_establishConnection();
            $sql = "SELECT s.ProductosPedidos AS 'ProductosPedidos', e.TipoEstado AS 'TipoEstado' FROM solicitud_pedidos s INNER JOIN estados_pedidos e ON s.TipoEstado = e.Id_estado WHERE Id_usuarioSolicitante = :idUsuario";
            $stmt = $methodToConnect->prepare($sql);
            $stmt->bindParam(":idUsuario", $id, PDO::PARAM_INT);
            $booleanResult = $stmt->execute();
            if($booleanResult) {
                while($result = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $ordersRequested[] = $result;
                }
                return $ordersRequested;
            } else {
                return "<div class='alert alert-danger' role='alert'>Aun no se encuentra ninguna solicitud de pedidos ingresados por su usuario.</div>";
            }
            
        }catch(PDOException $e) {
            echo '{"error":{"text":'.$e->getMessage().'}}';
        }
    }
}
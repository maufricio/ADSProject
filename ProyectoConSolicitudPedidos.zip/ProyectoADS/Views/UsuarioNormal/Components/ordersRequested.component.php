<?php

require_once '../../Models/Connection.class.php';
require_once '../../Models/UsersStatements.class.php';

function exportOrdersRequestedByThisUser($idUsuario) {
    $ordersModel = new UserStatements();
    $ordersRequestedPacked = $ordersModel->selectOrderRequestsByUser($idUsuario);
    if(is_array($ordersRequestedPacked) || is_object($ordersRequestedPacked)) {
        foreach ($ordersRequestedPacked as $ordersRequestedData) {
            ?>
            <table class="table ">
                <thead>
                    <th scope="col">Productos Ordenados</th>
                    <th scope="col">Estado de Solicitud</th>
                </thead>
                <tbody>
                    <tr>
                        <td scope="col" class='table-info' role='alert'><?php echo $ordersRequestedData['ProductosPedidos']; ?></td>
                        <td scope="col" class='table-warning' role='alert'><?php echo $ordersRequestedData['TipoEstado']; ?></td>
                    </tr>
                </tbody>
            </table>
            <?php
        }
    }
}
?>
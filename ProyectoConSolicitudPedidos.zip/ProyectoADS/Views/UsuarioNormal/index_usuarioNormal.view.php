<?php 

require_once '../../Models/Connection.class.php';
require_once '../../Models/UsersStatements.class.php';
require_once '../../Controllers/session.controller.php';
require_once '../../Controllers/Users/UserData.controller.php';

//Components
require_once 'Components/orderRequestsForm.component.php';
require_once 'Components/ordersRequested.component.php';

$session_uid = session();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagina Principal Usuario - Panes Chory</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>
    <a href="../../Controllers/close_session.controller.php">Cerrar Sesión</a>
    
    <div id="SeeProducts">
        <table>
            <thead>

            </thead>
            <tbody>

            </tbody>
        </table>
    </div>


    <h1>Página principal de Usuario - Panes Chory</h1>
    <div id="makeOrderDiv">
        <?php echo printOderRequestForm($session_uid); ?>
        <?php 
            if(isset($_GET['accion'])){
                ?>
                    <div class='alert alert-success' role='alert'>Solicitud de pedido completada con exito.</div>
                <?php
            }
        ?>
    </div>
    

    <div id="getOrdersRequests">
        <h3>Solicitudes de ordenes de pedidos</h3>
        <?php echo exportOrdersRequestedByThisUser($session_uid); ?>
    </div>

    <div id="getOrders">
        <h3>Pedidos Despachados</h3>
        
    </div>
</body>
</html>

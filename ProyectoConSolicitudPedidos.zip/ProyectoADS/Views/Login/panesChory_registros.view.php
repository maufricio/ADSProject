<?php
  require_once '../../Controllers/UserSignUp.controller.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro Panes Chory</title>
    
    <link rel="stylesheet" type="text/css" href="../styles/styleLogin.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body class="bg">

    <div class="container pt-5" id="form">
        <h2 class="text-center">
            Registro de usuarios <br/> Venta de Combustible
        </h2>
        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="POST">
        <div class="row pt-3">
            <div class="col-6">
                 <div class="form-group pb-2">
                    <label for="nombre1">Nombre</label>
                    <input type="text" name="nombre1" id="nombre1" placeholder = "Primer Nombre" class="form-control" autocomplete="off">
                  </div>
            </div>
            <div class="col-6">
                 <div class="form-group pb-2">
                    <label for="apellido1">Apellido</label>
                    <input type="text" name="apellido1" id="apellido1" class="form-control"  placeholder="Primer Apellido" autocomplete="off">
                  </div>
            </div>

            <div class="col-6">
                 <div class="form-group pb-2">
                    <label for="email">Correo Electrónico</label>
                    <input type="email" name="emailUsuario" id="emailUsuario" class="form-control"  placeholder="Correo Electronico" autocomplete="off">
                  </div>
            </div>
        </div>

          <div class="row pt-3">
            <div class="col-6">
                 <div class="form-group pb-2">
                    <label for="username">Username</label>
                    <input type="text" name="username" id="username" class="form-control"  placeholder="userName" autocomplete="off">
                  </div>
            </div>

            <div class="col-6">
                  <div class="form-group pb-2">
                    <label for="password">Contraseña</label>
                    <input type="password" name="password" id="password" placeholder="Contraseña" class="form-control" autocomplete="off">
                  </div>
            </div>
          </div>
        <div id="errors-container">
          <?php echo $msgErrorReg;?>
        </div>
            <div class="text-end">
              <div class="pt-3 pb-4">
                <button type="submit" name="registrarB" id="registrarB" value="Registrar Usuario" class="btn btn-primary btn-lg ">Registrarse</button>  
                <h4>O Inicie sesión <a href="panesChory_login.view.php">Aquí</a></h4>
              </div>
            </div>
        </form>

       
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

</body>
</html>
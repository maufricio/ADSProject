<?php
require_once '../../Models/Connection.class.php';
require_once '../../Models/UsersStatements.class.php';
require_once 'session.controller.php';
require_once 'login.controller.php';

$errorMsgLogin = '';

if(isset($_POST['ingresarB'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    if(strlen($username) > 0 && strlen($password) > 0) {
        $errorMsgLogin = login($username, $password);
    }else{
        $errorMsgLogin = '<div class="alert alert-danger" role="alert">Llenar campos requeridos.</div>';
    }
}
?>
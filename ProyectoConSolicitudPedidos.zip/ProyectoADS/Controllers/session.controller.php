<?php
    function session(){
        session_start();
        if(!empty($_SESSION['Id_usuarios']))
            return $_SESSION['Id_usuarios'];
        if(empty($session_uid))
        {
            $url='../Login/panesChory_login.view.php';
            header("Location: $url");
        }
    }
?>
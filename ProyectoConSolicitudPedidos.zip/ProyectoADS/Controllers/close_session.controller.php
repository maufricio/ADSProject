<?php

include_once '../Models/Connection.class.php';

function close_session() {
    session_start();
    unset($session_uid);
    session_destroy();
    $url = "../Views/Login/panesChory_login.view.php";
    header("Location: $url");
}

echo close_session();
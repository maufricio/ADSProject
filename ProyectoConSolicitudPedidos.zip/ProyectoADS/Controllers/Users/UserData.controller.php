<?php
require_once '../../Models/Connection.class.php';
require_once '../../Models/UserConfiguration.class.php';

function exportUsernameToView($idNumber) {
    $usernameExportado = "";
    $userConfigurationModel = new UserConfiguration();
    $dataReturned = $userConfigurationModel->convertFromIdToName($idNumber);
    if(count($dataReturned)) {
        if(is_array($dataReturned) || is_object($dataReturned)) {
            foreach ($dataReturned as $username) {
                $usernameExportado = $username['UsernameUsuario'];
            }
        }
        return $usernameExportado;
    } else {
        return "<div class='alert alert-danger' role='alert'>Revisa tu nombre de usuario registrado o contraseña.</div>";
    }
}

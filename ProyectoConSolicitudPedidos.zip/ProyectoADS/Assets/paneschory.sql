-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 05, 2022 at 10:44 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `paneschory`
--

-- --------------------------------------------------------

--
-- Table structure for table `estados_pedidos`
--

CREATE TABLE `estados_pedidos` (
  `Id_estado` int(11) NOT NULL,
  `TipoEstado` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pedidos`
--

CREATE TABLE `pedidos` (
  `Id_pedido` int(11) NOT NULL,
  `Id_solicitudPedidos` int(11) DEFAULT NULL,
  `Id_transporte` int(11) DEFAULT NULL,
  `TipoEstado` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `productos`
--

CREATE TABLE `productos` (
  `Id_Producto` int(11) NOT NULL,
  `NombreProducto` varchar(50) DEFAULT NULL,
  `Existencias` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `roles_usuarios`
--

CREATE TABLE `roles_usuarios` (
  `Id_rol` int(11) NOT NULL,
  `NombreRol` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `solicitud_pedidos`
--

CREATE TABLE `solicitud_pedidos` (
  `Id_solicitudPedido` int(11) NOT NULL,
  `Id_usuarioSolicitante` int(11) DEFAULT NULL,
  `ProductosPedidos` varchar(100) DEFAULT NULL,
  `TipoEstado` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `transporte`
--

CREATE TABLE `transporte` (
  `Id_transporte` int(11) NOT NULL,
  `PlacaTransporte` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `usuarios_chory`
--

CREATE TABLE `usuarios_chory` (
  `Id_usuarios` int(11) NOT NULL,
  `NombreUsuario` varchar(50) NOT NULL,
  `ApellidoUsuario` varchar(50) NOT NULL,
  `CorreoUsuario` varchar(50) NOT NULL,
  `RolUsuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `estados_pedidos`
--
ALTER TABLE `estados_pedidos`
  ADD PRIMARY KEY (`Id_estado`);

--
-- Indexes for table `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`Id_pedido`),
  ADD KEY `Id_solicitudPedidos` (`Id_solicitudPedidos`),
  ADD KEY `Id_transporte` (`Id_transporte`),
  ADD KEY `TipoEstado` (`TipoEstado`);

--
-- Indexes for table `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`Id_Producto`);

--
-- Indexes for table `roles_usuarios`
--
ALTER TABLE `roles_usuarios`
  ADD PRIMARY KEY (`Id_rol`);

--
-- Indexes for table `solicitud_pedidos`
--
ALTER TABLE `solicitud_pedidos`
  ADD PRIMARY KEY (`Id_solicitudPedido`),
  ADD KEY `Id_usuarioSolicitante` (`Id_usuarioSolicitante`),
  ADD KEY `TipoEstado` (`TipoEstado`);

--
-- Indexes for table `transporte`
--
ALTER TABLE `transporte`
  ADD PRIMARY KEY (`Id_transporte`);

--
-- Indexes for table `usuarios_chory`
--
ALTER TABLE `usuarios_chory`
  ADD PRIMARY KEY (`Id_usuarios`),
  ADD KEY `fk_rolusuario` (`RolUsuario`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `estados_pedidos`
--
ALTER TABLE `estados_pedidos`
  MODIFY `Id_estado` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `Id_pedido` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `productos`
--
ALTER TABLE `productos`
  MODIFY `Id_Producto` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles_usuarios`
--
ALTER TABLE `roles_usuarios`
  MODIFY `Id_rol` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `solicitud_pedidos`
--
ALTER TABLE `solicitud_pedidos`
  MODIFY `Id_solicitudPedido` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transporte`
--
ALTER TABLE `transporte`
  MODIFY `Id_transporte` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `usuarios_chory`
--
ALTER TABLE `usuarios_chory`
  MODIFY `Id_usuarios` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`Id_solicitudPedidos`) REFERENCES `solicitud_pedidos` (`Id_solicitudPedido`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pedidos_ibfk_2` FOREIGN KEY (`TipoEstado`) REFERENCES `estados_pedidos` (`Id_estado`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pedidos_ibfk_3` FOREIGN KEY (`Id_transporte`) REFERENCES `transporte` (`Id_transporte`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `solicitud_pedidos`
--
ALTER TABLE `solicitud_pedidos`
  ADD CONSTRAINT `solicitud_pedidos_ibfk_1` FOREIGN KEY (`TipoEstado`) REFERENCES `estados_pedidos` (`Id_estado`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `solicitud_pedidos_ibfk_2` FOREIGN KEY (`Id_usuarioSolicitante`) REFERENCES `usuarios_chory` (`Id_usuarios`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `usuarios_chory`
--
ALTER TABLE `usuarios_chory`
  ADD CONSTRAINT `fk_rolusuario` FOREIGN KEY (`RolUsuario`) REFERENCES `roles_usuarios` (`Id_rol`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

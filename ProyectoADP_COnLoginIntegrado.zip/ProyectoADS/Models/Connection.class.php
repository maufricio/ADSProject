<?php

class Connection {
    private $conexion;
    private $user;
    private $pass;
    private $server;
    private $dbname;

    public function __construct() {
        $this->conexion = "";
        $this->user = "root";
        $this->pass = null;
        $this->server = "localhost";
        $this->dbname = "paneschory";
        //$this->_establishConnection($this->user, $this->pass, $this->server, $this->dbname);
    }

    public function _establishConnection() {
        try{
            $this->conexion = new PDO("mysql:dbname=$this->dbname;host=$this->server", $this->user, $this->pass);
            return $this->conexion;
        }catch(PDOException $e) {
            $err = "Conexion a la base de datos fallida. Revise la clase de la conexión. " . $e->getMessage();
            return $err; 
        }
    }

    public static function _killConnection($conexion) {
        try{
            $conexion = null;
            return $conexion;
        }catch(PDOException $e) {
            $err = "Conexion a la base de datos fallida. Revise la clase de la conexión. " . $e->getMessage();
            return $err;
        }
    }
}
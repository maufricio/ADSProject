<?php
    require_once '../../Controllers/UserSignIn.controller.php';
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sala de Sesión - Panes Chory</title>

    <link rel="stylesheet" type="text/css" href="../../Public/Styles/styleLogin.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body class="bg">

    <div class="container pt-5" id="formulario-login-container">
        <div id="login-presentation-container">
            <h2 class="text-center pb-5 coor">Sala de Sesión <br>-<br/> Panes Chory</h2>
            <div id="image-login-container">
                    <img src="../../Public/Images/icono-login.svg" alt="imgLogin" id="imagenLogin">
                </div>
        </div>
        
        
        <div class="row d-flex justify-content-center">
            
            <div class="col-6">
          
                <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST" id="login-formulario">
                <div id="separator-login-container">
                    <img src="../../Public/Images/blank-line.png" alt="imgLogin" id="imagenLogin">
                </div>
                  <div class="form-group pb-2">
                    <label for="username">Nombre de usuario</label>
                    <input type="text" name="username" id="username" class="form-control"  placeholder="userName" autocomplete="off">
                  </div>

                  <div class="form-group pb-2">
                        <label for="exampleFormControlInput1">Contraseña</label>
                        <input class="form-control" type="password" name="password" id="password" placeholder="Contraseña de usuario">
                  </div>

                   <div class="pt-3 pb-4">
                        <button type="submit" name="ingresarB" id="ingresarB" value="Iniciar Sesión"class="btn btn-primary btn-lg ">Iniciar Sesión</button>  
                   </div>
                   
                </form>   

                    <p>¿No tienes cuenta? Regístrese 
                        <a href="panesChory_registros.view.php">Aquí</a>
                    </p>
                    <a href="#" id="dontRememberPassLink">¿No recuerda su contraseña?</a>
                     <?php echo $errorMsgLogin;
                    ?>
               
            </div>
        </div>

        

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>
<?php
//Se pone doble salida de carpeta debido a que lo estoy requiriendo luego en las vistas para poder ejecutar
require_once '../../Models/Connection.class.php';
require_once '../../Models/UsersStatements.class.php';

    $msgErrorReg = '';
    if(isset($_POST['registrarB'])) {
        @$nombre1 = $_POST['nombre1'] ? $_POST['nombre1'] : "";
        $apellido1 = $_POST['apellido1'] ? $_POST['apellido1'] : "";
        $email = $_POST['emailUsuario'] ? $_POST['emailUsuario'] : "";
        $username = $_POST['username'] ? $_POST['username'] : "";
        $password = $_POST['password'] ? $_POST['password'] : "";
        if(strlen($nombre1) > 0 && strlen($apellido1) > 0 && strlen($username) > 0 && strlen($password) > 0) {
          $functions = new UserStatements();
          $statusTransfer = $functions->registerUser($nombre1, $apellido1, $email, $username, $password);
          echo $statusTransfer;
          $msgErrorReg = "<div class='alert alert-success' role='alert'>Usuario registrado exitosamente.</div>";
      }else{
        $msgErrorReg = "<div class='alert alert-danger' role='alert'>Llenar campos requeridos.</div>";
      }
    }
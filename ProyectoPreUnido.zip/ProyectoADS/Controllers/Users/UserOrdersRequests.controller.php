<?php
require_once '../../Models/Connection.class.php';
require_once '../../Models/UsersStatements.class.php';


if(isset($_POST['ingresarB']) ? $_POST['ingresarB'] : 0) {
    $idUsuario = $_GET['UsuarioNormal'];
    $producto1 = $_POST['product2Order1'] ? $_POST['product2Order1'] : "Ningun Producto";
    $producto2 = $_POST['product2Order2'] ? $_POST['product2Order2'] : "Ningun Producto";
    $producto3 = $_POST['product2Order3'] ? $_POST['product2Order3'] : "Ningun Producto";
    $producto4 = $_POST['product2Order4'] ? $_POST['product2Order4'] : "Ningun Producto";
    $producto5 = $_POST['product2Order5'] ? $_POST['product2Order5'] : "Ningun Producto";

    $stringUnificadoProductos = $producto1 . "; " . $producto2 . "; " . $producto3 . "; " . $producto4 . "; " . $producto5;

    $orderRequestObject = new UserStatements();
    $orderRequestObject->insertOrderRequest($idUsuario, $stringUnificadoProductos);

    $url = "../../Views/UsuarioNormal/index_usuarioNormal.view.php?UsuarioNormal=$idUsuario&accion=Completada_con_exito";
    header("Location: $url");
}
<?php

require_once '../../Models/Connection.class.php';
require_once '../../Models/UsersStatements.class.php';

function login($username, $password){
    $userClass = new UserStatements();
    $uid = $userClass->userLogin($username, $password);
    if($uid)
    {
        session_start();
        $session_uid = session();
        $url = '';
        //if(is_integer($session_uid) || gettype($session_uid) == 'integer') {
            if($_SESSION['RolUsuario'] == 2) {
                $url = '../Administrador/index_admin.view.php?Administrador=' . hash('sha256', $_SESSION['Id_usuarios']);
                //Vista para administrador
            } else if($_SESSION['RolUsuario'] == 1) {
                //Vista para usuario normal
                $url = '../UsuarioNormal/index_usuarioNormal.view.php?UsuarioNormal=' . hash('sha256', $_SESSION['Id_usuarios']);
            }
            header("Location: $url");  // Page redirecting to views
       // }
    }   
    else
    {
        return "<div class='alert alert-danger' role='alert'>Revisa tu nombre de usuario registrado o contraseña.</div>";
    }
}
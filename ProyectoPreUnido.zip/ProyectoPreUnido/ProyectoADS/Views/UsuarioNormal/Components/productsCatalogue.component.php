<?php
require_once '../../Models/Connection.class.php';
require_once '../../Models/UsersStatements.class.php';

function printProductsCatalogue() {
    $catalogue = new UserStatements();
    $dataPacked = $catalogue->selectProductsOffered();
    
        if(is_array($dataPacked) || is_object($dataPacked)) {
            foreach ($dataPacked as $data) {
                ?>
                <table class="table">
                        <thead>
                            <th scope="col">Producto Ofertado</th>
                            <th scope="col">Existencias de Producto</th>
                        </thead>
                        <tbody>
                            <tr>
                                <td scope="col" class='table-primary' role='alert'><?php echo $data['productName']; ?></td>
                                <td scope="col" class='table-danger' role='alert'><?php echo $data['existences']; ?></td>
                            </tr>
                        </tbody>
                    </table>
                <?php
            }
        }
}
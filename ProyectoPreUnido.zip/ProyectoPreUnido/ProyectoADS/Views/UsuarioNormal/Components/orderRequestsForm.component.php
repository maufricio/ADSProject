<?php function printOderRequestForm($sessionNumber) {?>

<div class="row d-flex justify-content-center">
            
            <div class="col-6">
          
                <form action="../../Controllers/Users/UserOrdersRequests.controller.php?UsuarioNormal=<?php echo $sessionNumber; ?>" method="POST" id="ordersRequestsForm">
                 <div class="form-group pb-2 pt-3"> 
                   <label for="username">Nombre de usuario que ordena: </label>
                    <input type="text" name="username" id="username" class="form-control" value="<?php echo exportUsernameToView($sessionNumber); ?>" autocomplete="off" readonly>
                  </div>
                  <div class="form-group pb-2 pt-3"> 
                   <input type="text" name="product2Order1" id="product2Order1" placeholder="Producto a ordenar" class="form-control">
                   </div>
                   <div class="form-group pb-2 pt-3"> 
                   <input type="text" name="product2Order2" id="product2Order2" placeholder="Producto a ordenar" class="form-control">
                   </div>
                   <div class="form-group pb-2 pt-3"> 
                   <input type="text" name="product2Order3" id="product2Order3" placeholder="Producto a ordenar" class="form-control">
                   </div>
                   <div class="form-group pb-2 pt-3"> 
                   <input type="text" name="product2Order4" id="product2Order4" placeholder="Producto a ordenar" class="form-control">
                   </div>
                   <div class="form-group pb-2 pt-3"> 
                   <input type="text" name="product2Order5" id="product2Order5" placeholder="Producto a ordenar" class="form-control">
                   </div>
                   <div class="pt-3 pb-4">
                        <button type="submit" name="ingresarB" id="ingresarB" value="Iniciar Sesión" class="btn btn-primary btn-lg ">Ordenar Pedido</button>  
                   </div>
                   
                </form>   
               
            </div>
</div>

<?php
}
?>

<?php
//esta pagina solo es el menu de sitio 
//puede añadir la con 
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>menu</title>
    <link rel="stylesheet" type="text/css" href="../../Public/Styles/style.css">
</head>
<body>
<ul class="menu">

<a href="#"><img src="../../Public/Images/logo.jpeg" alt=""></a>

<?php//Aqui va los enlaces de las otras paginas #?>
<li><a href="principal.php"><h2>INICIO</h2></a></li> 
<li><a href="index.php"><h2>NOTICIA</h2></a></li>
<li><a href="index.php"><h2>BLOG</h2></a></li>
<li><a href="../../Views/UsuarioNormal/index_usuarioNormal.view.php"><h2>PEDIDOS</h2></a></li>
<li><a href="#"><h2>MI PERFIL</h2></a></li>

<a class="btnCerrar" href="../../Controllers/close_session.controller.php">Cerrar Sesión</a>
</ul>  
</body>
</html>

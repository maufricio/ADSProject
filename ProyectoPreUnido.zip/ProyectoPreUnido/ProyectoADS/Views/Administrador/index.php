<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="icon" type="icon/png" href="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTOCBRgblymSAphuE6FTVAqm097qKKoCaUdQJjRRlgDf0CH5wMmao0EIzfKTTFj9uZFm-c&usqp=CAU">
	<link rel="stylesheet" type="text/css" href="../../Public/Styles/index.css">
	<link rel="stylesheet" type="text/css" href="../../Public/Styles/stylefooter.css">

	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Pagina en mejora</title>
</head>
<body>
<?php //llamando la pagina de menu
 require 'navbar.php';?> 
	<nav id="Nav">
		<h1>Pagina en Mantenimiento</h1>

	</nav>
	<div class="alinear">
			<img src="../../Public/Images/pagina.png" width="550" height="550">
	</div>
	
	<div class="footer">
	<h2>Esta pagina esta en mantenimiento muy pronto estara disponible gracias por su comprencion<h2> 
</div>
<?php //llamando el footer
 require '../../Public/Html/index.html';?>

</body>
</html>
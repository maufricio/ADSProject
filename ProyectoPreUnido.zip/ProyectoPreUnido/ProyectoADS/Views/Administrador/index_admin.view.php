<?php 

require_once '../../Models/Connection.class.php';
require_once '../../Models/UsersStatements.class.php';
require_once '../../Controllers/session.controller.php';

$session_uid = session();

//llamando la pagina principal
require 'principal.php';